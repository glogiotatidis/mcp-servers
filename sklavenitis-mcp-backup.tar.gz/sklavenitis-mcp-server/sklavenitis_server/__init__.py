"""MCP Server for Sklavenitis.gr grocery store."""

__version__ = "0.1.0"
